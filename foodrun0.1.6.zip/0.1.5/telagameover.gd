extends Node

func _ready() -> void:
	connect("visibility_changed", _atualizar_pontuacao)

func _atualizar_pontuacao() -> void:
	if get("visible"):
		var label = find_child("PontuacaoLabel", true, false)
		if label:
			label.text = "Pontuação: " + str(Global.score)
