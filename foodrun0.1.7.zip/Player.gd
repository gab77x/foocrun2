extends CharacterBody2D

# --- Velocidade progressiva ---
const BASE_SPEED = 400.0       # velocidade inicial
const SPEED_STEP = 25.0        # quanto a velocidade sobe a cada degrau
const MAX_SPEED = 600.0        # velocidade máxima
const POINTS_PER_STEP = 350.0  # pontos necessários para cada degrau
var SPEED = BASE_SPEED         # velocidade atual (o criachao lê esta variável)

# --- Pulo ---
const AIR_SPEED_MULTIPLIER = 1.18
const JUMP_VELOCITY = -660.0
const RISE_GRAVITY_MULTIPLIER = 1.5
const FALL_GRAVITY_MULTIPLIER = 3.0  # quão rápido o personagem cai após o pulo
const APEX_THRESHOLD = 350.0  # faixa de velocidade vertical considerada "perto do topo"
const APEX_GRAVITY_MULTIPLIER = 0.63  # gravidade menor perto do topo (pairar)
const VOID_Y_LIMIT = 900.0  # ajuste esse valor conforme necessário

func _ready():
	$personagem.play("default")

func _physics_process(delta: float) -> void:
	# A velocidade sobe um degrau a cada POINTS_PER_STEP pontos
	var degraus: int = floori(Global.score / POINTS_PER_STEP)
	SPEED = minf(BASE_SPEED + degraus * SPEED_STEP, MAX_SPEED)

	# Adiciona a gravidade se não estiver no chão
	if not is_on_floor():
		var g = get_gravity()
		if velocity.y > 0:
			# Está caindo: gravidade mais forte
			g *= FALL_GRAVITY_MULTIPLIER
		else:
			# Está subindo: gravidade um pouco mais forte
			g *= RISE_GRAVITY_MULTIPLIER
		# Perto do ponto mais alto: gravidade menor (pairar)
		if absf(velocity.y) < APEX_THRESHOLD:
			g *= APEX_GRAVITY_MULTIPLIER
		velocity += g * delta

	# Movimento automático: um pouco mais rápido enquanto está no ar
	if is_on_floor():
		velocity.x = SPEED
	else:
		velocity.x = SPEED * AIR_SPEED_MULTIPLIER

	# Condição de pulo: aceita "Espaço", "Seta para Cima" ou "W"
	if is_on_floor() and (Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)):
		velocity.y = JUMP_VELOCITY

	move_and_slide()

	Global.add_distance(velocity.x * delta)

	if is_on_wall():
		$personagem.stop()
	else:
		if not $personagem.is_playing():
			$personagem.play("default")

	# Verifica se caiu no void
	if global_position.y > VOID_Y_LIMIT:
		_trigger_game_over()

func _trigger_game_over() -> void:
	set_physics_process(false)
	get_tree().paused = true
	get_node("/root/Game/gameoverlayer/telagameover").visible = true
