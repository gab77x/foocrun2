extends CanvasLayer

const OPCOES_SCENE := preload("res://opcoes.tscn")
const MENU_SCENE := "res://menu.tscn"

@onready var continuar: Button = %continuar
@onready var opcoes: Button = %opcoes
@onready var menu: Button = %menu

var _opcoes_aberto: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	continuar.pressed.connect(_retomar)
	opcoes.pressed.connect(_abrir_opcoes)
	menu.pressed.connect(_ir_para_menu)

func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("ui_cancel"):
		return
	if _opcoes_aberto:
		return

	if visible:
		_retomar()
	elif _pode_pausar():
		_pausar()
	get_viewport().set_input_as_handled()

func _pode_pausar() -> bool:
	if get_tree().paused:
		return false
	var tela = get_tree().current_scene.find_child("telagameover", true, false)
	if tela and tela.get("visible"):
		return false
	return true

func _pausar() -> void:
	get_tree().paused = true
	visible = true
	continuar.grab_focus()

func _retomar() -> void:
	get_tree().paused = false
	visible = false

func _abrir_opcoes() -> void:
	_opcoes_aberto = true
	var painel := OPCOES_SCENE.instantiate()
	add_child(painel)
	painel.fechado.connect(_on_opcoes_fechado)

func _on_opcoes_fechado() -> void:
	_opcoes_aberto = false
	opcoes.grab_focus()

func _ir_para_menu() -> void:
	get_tree().paused = false
	Global.reset_score()
	get_tree().change_scene_to_file(MENU_SCENE)
