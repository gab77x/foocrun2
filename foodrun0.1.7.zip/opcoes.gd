extends Control

signal fechado

@onready var slider: HSlider = %slider
@onready var valor: Label = %valor
@onready var voltar: Button = %voltar

func _ready() -> void:
	slider.value = Config.volume_musica
	atualizar_texto(slider.value)
	slider.value_changed.connect(_on_slider)
	voltar.pressed.connect(_on_voltar)
	slider.grab_focus()

func _on_slider(novo_valor: float) -> void:
	Config.definir_volume_musica(novo_valor)
	atualizar_texto(novo_valor)

func atualizar_texto(v: float) -> void:
	valor.text = str(roundi(v * 100.0)) + "%"

func _on_voltar() -> void:
	Config.salvar()
	fechado.emit()
	queue_free()
