extends Control

const INTRO_SCENE := "res://intro.tscn"
const OPCOES_SCENE := preload("res://opcoes.tscn")

@onready var btjogar: Button = $CenterContainer/VBoxContainer/btjogar
@onready var btopcoes: Button = $CenterContainer/VBoxContainer/btopcoes
@onready var btsair: Button = $CenterContainer/VBoxContainer/btsair

func _ready() -> void:
	Musica.tocar_menu()
	btjogar.pressed.connect(_on_jogar)
	btopcoes.pressed.connect(_on_opcoes)
	btsair.pressed.connect(func(): get_tree().quit())
	btjogar.grab_focus()

func _on_jogar() -> void:
	get_tree().change_scene_to_file(INTRO_SCENE)

func _on_opcoes() -> void:
	var painel_opcoes := OPCOES_SCENE.instantiate()
	add_child(painel_opcoes)
	painel_opcoes.fechado.connect(_on_opcoes_fechado)

func _on_opcoes_fechado() -> void:
	btopcoes.grab_focus()
