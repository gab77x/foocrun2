extends Label

func _process(_delta: float) -> void:
	text = "PONTUAÇÃO: %d" % Global.score
