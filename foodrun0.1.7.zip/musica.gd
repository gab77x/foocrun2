extends Node

const MUSICA_MENU := preload("res://musicas/menusong.mp3")

var _player: AudioStreamPlayer

func _ready() -> void:
	_player = AudioStreamPlayer.new()
	_player.stream = MUSICA_MENU
	_player.bus = "Musica"
	_player.volume_db = -20
	add_child(_player)

func tocar_menu() -> void:
	if not _player.playing:
		_player.play()

func parar() -> void:
	_player.stop()
