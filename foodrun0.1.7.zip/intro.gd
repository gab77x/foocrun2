extends Control

const GAME_SCENE := "res://game.tscn"
@export var chars_per_second: float = 40.0

const COR_FALANDO := Color(1, 1, 1, 1)
const COR_QUIETO := Color(0.45, 0.45, 0.45, 1)

# "quem" é "yana" ou "viktor". "aviso" é opcional.
var falas: Array[Dictionary] = [
	{
		"quem": "yana", "nome": "YANA",
		"texto": "Filho, a nossa cidade está passando por um momento difícil...\nTem certeza que consegue ir buscar mantimentos?"
	},
	{
		"quem": "viktor", "nome": "VIKTOR",
		"texto": "Mãe, eu preciso ajudar as pessoas, a gente desperdiçou tanto, e agora a situação chegou nesse ponto..."
	},
	{
		"quem": "yana", "nome": "YANA",
		"texto": "Tudo bem, Viktor, só tome cuidado. Se ver espinhos ou buracos, pule deles, ok?",
		"aviso": "Pressione ESPAÇO, W ou ↑ para pular"
	},
	{
		"quem": "viktor", "nome": "VIKTOR",
		"texto": "Não se preocupa, mãe, eu sei me virar :]"
	},
]

@onready var nome_label: Label = $balao/MarginContainer/VBoxContainer/nome
@onready var texto_label: Label = $balao/MarginContainer/VBoxContainer/textofala
@onready var dica: Label = $balao/MarginContainer/VBoxContainer/dica
@onready var yana: TextureRect = $personagens/YANA
@onready var viktor: TextureRect = $personagens/VIKTOR
@onready var aviso_botao: Label = $avisobotao

var indice := 0
var tween: Tween
var digitando := false

func _ready() -> void:
	mostrar_fala()

func mostrar_fala() -> void:
	var fala := falas[indice]
	nome_label.text = fala["nome"]
	texto_label.text = fala["texto"]
	texto_label.visible_ratio = 0.0
	dica.visible = false
	digitando = true

	destacar(fala["quem"])
	atualizar_aviso(fala)

	var duracao: float = fala["texto"].length() / chars_per_second
	tween = create_tween()
	tween.tween_property(texto_label, "visible_ratio", 1.0, duracao)
	tween.finished.connect(_terminou_de_digitar)

func atualizar_aviso(fala: Dictionary) -> void:
	if fala.has("aviso"):
		aviso_botao.text = fala["aviso"]
		aviso_botao.visible = true
	else:
		aviso_botao.visible = false

func destacar(quem: String) -> void:
	yana.modulate = COR_FALANDO if quem == "yana" else COR_QUIETO
	viktor.modulate = COR_FALANDO if quem == "viktor" else COR_QUIETO

func _terminou_de_digitar() -> void:
	digitando = false
	dica.visible = true

func _unhandled_input(event: InputEvent) -> void:
	var avancar: bool = false
	

	if event.is_action_pressed("ui_accept"):
		avancar = true
	elif event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			avancar = true

	if not avancar:
		return

	if digitando:
		tween.kill()
		texto_label.visible_ratio = 1.0
		_terminou_de_digitar()
	else:
		indice += 1
		if indice >= falas.size():
				Musica.parar()
				get_tree().change_scene_to_file(GAME_SCENE)
		else:
			mostrar_fala()
