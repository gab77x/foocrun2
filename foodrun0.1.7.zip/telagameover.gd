extends Node

const FATOS: Array[String] = [
	"Em 2025, cerca de 645 milhões de pessoas passaram fome no mundo. Por isso, não desperdice!",
	"Você sabia? Todos os dias, mais de 1 bilhão de refeições são desperdiçadas no mundo. Isso daria + de uma refeição por dia para cada um que passa fome :[",
	"Coloque no prato somente o que você realmente aguenta comer. Previna o desperdício!",
]

var _processado: bool = false
var _novo_recorde: bool = false
var _fato_atual: String = ""

func _ready() -> void:
	connect("visibility_changed", _atualizar_pontuacao)

func _sortear_fato() -> String:
	var indice: int = randi() % FATOS.size()
	while indice == Global.ultimo_fato and FATOS.size() > 1:
		indice = randi() % FATOS.size()
	Global.ultimo_fato = indice
	return FATOS[indice]

func _atualizar_pontuacao() -> void:
	if not get("visible"):
		return

	if not _processado:
		_processado = true
		_novo_recorde = Global.atualizar_recorde()
		_fato_atual = _sortear_fato()

	var label_fato = find_child("frases", true, false)
	var label_pontos = find_child("pontuacaolabel", true, false)
	var label_recorde = find_child("recordelabel", true, false)

	if label_fato:
		label_fato.text = _fato_atual

	if label_pontos:
		label_pontos.text = "Pontuação: " + str(Global.score)

	if label_recorde:
		if _novo_recorde:
			label_recorde.text = "Novo recorde: " + str(Global.recorde) + "!"
		else:
			label_recorde.text = "Recorde: " + str(Global.recorde)
