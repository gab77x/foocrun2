extends AudioStreamPlayer

# quantos segundos de silêncio existem no fim da música
@export var silencio_no_fim: float = 5.0

func _process(_delta: float) -> void:
	if playing and stream:
		if get_playback_position() >= stream.get_length() - silencio_no_fim:
			seek(0.0)
