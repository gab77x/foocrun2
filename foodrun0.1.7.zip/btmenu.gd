extends Button

func _ready() -> void:
	pressed.connect(_on_pressed)

func _on_pressed() -> void:
	get_tree().paused = false
	Global.reset_score()
	get_tree().change_scene_to_file("res://menu.tscn")
