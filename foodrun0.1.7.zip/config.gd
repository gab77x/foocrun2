extends Node

const ARQUIVO := "user://config.cfg"
const BUS := "Musica"

var volume_musica: float = 1.0

func _ready() -> void:
	carregar()
	aplicar_volume()

func definir_volume_musica(valor: float) -> void:
	volume_musica = clampf(valor, 0.0, 1.0)
	aplicar_volume()

func aplicar_volume() -> void:
	var idx: int = AudioServer.get_bus_index(BUS)
	if idx == -1:
		return
	AudioServer.set_bus_volume_db(idx, linear_to_db(volume_musica))
	AudioServer.set_bus_mute(idx, volume_musica <= 0.0)

func salvar() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "volume_musica", volume_musica)
	cfg.save(ARQUIVO)

func carregar() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(ARQUIVO) == OK:
		volume_musica = cfg.get_value("audio", "volume_musica", 1.0)
